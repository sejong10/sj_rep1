for loop_counter in [1,2,3,4,5]:
    print loop_counter,": Hello"
print "End of For Loop!!!"
