input1 = raw_input("Enter the first input value : ")
input2 = raw_input("Enter the second input value : ")

while input1 < input2:
    print input1, " is less than ", input2
    input1 = raw_input("Enter the first input value : ")
    input2 = raw_input("Enter the second input value : ")

print "At last ", input1, " is not less than ", input2

