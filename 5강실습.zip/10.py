for char in [ 'a', 'b', 'c', 'd', 'e', 'f']:
    print char, " is an alphabet!"
