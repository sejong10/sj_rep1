x = 3
print x
3
if x < 5:
    x = x + 1
    print x
