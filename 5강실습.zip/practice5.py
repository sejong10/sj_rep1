Python 2.7.13 (v2.7.13:a06454b1afa1, Dec 17 2016, 20:42:59) [MSC v.1500 32 bit (Intel)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> 
================ RESTART: C:/Users/user/Desktop/�� ����/1.py ================
3
4
>>> 
================ RESTART: C:/Users/user/Desktop/�� ����/3.py ================
Enter the first input value : 4
Enter the second input value : 5
4  is less than  5
4  is not equal to  5
>>> 
================ RESTART: C:/Users/user/Desktop/�� ����/4.py ================
Enter the first input value : 7
Enter the second input value : 8
7  is less than  8
7  is not equal to  8
>>> 
================ RESTART: C:/Users/user/Desktop/�� ����/5.py ================
Enter the first input value : 5
Enter the second input value : 19
5  is not equal to  19
>>> 
================ RESTART: C:/Users/user/Desktop/�� ����/6.py ================
1 : Hello
2 : Hello
3 : Hello
4 : Hello
5 : Hello
End of For Loop!!!
>>> 
================ RESTART: C:/Users/user/Desktop/�� ����/7.py ================
1 : Hello
2 : Hello
3 : Hello
4 : Hello
5 : Hello
6 : Hello
7 : Hello
8 : Hello
9 : Hello
End of For Loop!!!
>>> 
================ RESTART: C:/Users/user/Desktop/�� ����/8.py ================
5
10
15
20
25
End of First Loop!!!
10
9
8
7
6
5
4
3
2
End of Second Loop!!!
>>> 
================ RESTART: C:/Users/user/Desktop/�� ����/9.py ================
10
9
8
7
6
5
4
3
2
1
Happy New Year~~!!!
>>> 
================ RESTART: C:/Users/user/Desktop/�� ����/10.py ================
a  is an alphabet!
b  is an alphabet!
c  is an alphabet!
d  is an alphabet!
e  is an alphabet!
f  is an alphabet!
>>> 
================ RESTART: C:/Users/user/Desktop/�� ����/11.py ================
Enter the first input value : 7
Enter the second input value : 10
At last  7  is not less than  10
>>> 
================ RESTART: C:/Users/user/Desktop/�� ����/7.py ================
1 : Hello
2 : Hello
3 : Hello
4 : Hello
5 : Hello
6 : Hello
7 : Hello
8 : Hello
9 : Hello
End of For Loop!!!
>>> 
================ RESTART: C:/Users/user/Desktop/�� ����/12.py ================
i =  1
Can this line be printed?
i =  2
Can this line be printed?
i =  3
>>> 
================ RESTART: C:/Users/user/Desktop/�� ����/13.py ================
i =  1
Can this line be printed?
i =  2
Can this line be printed?
i =  3
i =  4
Can this line be printed?
i =  5
Can this line be printed?
>>> 
================ RESTART: C:/Users/user/Desktop/�� ����/14.py ================
5  x  1  =  5
5  x  2  =  10
5  x  3  =  15
5  x  4  =  20
5  x  5  =  25
5  x  6  =  30
5  x  7  =  35
5  x  8  =  40
5  x  9  =  45
====================
6  x  1  =  6
6  x  2  =  12
6  x  3  =  18
6  x  4  =  24
6  x  5  =  30
6  x  6  =  36
6  x  7  =  42
6  x  8  =  48
6  x  9  =  54
====================
7  x  1  =  7
7  x  2  =  14
7  x  3  =  21
7  x  4  =  28
7  x  5  =  35
7  x  6  =  42
7  x  7  =  49
7  x  8  =  56
7  x  9  =  63
====================
>>> 
================ RESTART: C:/Users/user/Desktop/�� ����/15.py ================
How many stars do you want? 22
* * * * * * * * * * * * * * * * * * * * * *
>>> 
>>> 
