for loop_counter in range(1,10):
    print loop_counter,": Hello"

print "End of For Loop!!!"
