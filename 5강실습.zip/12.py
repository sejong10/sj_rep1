for i in range(1,6):
    print "i = ", i
    if i == 3:
        break
    print "Can this line be printed?"
